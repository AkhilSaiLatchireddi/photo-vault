"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const helmet_1 = __importDefault(require("helmet"));
const dotenv_1 = __importDefault(require("dotenv"));
const express_rate_limit_1 = __importDefault(require("express-rate-limit"));
const auth_middleware_1 = require("./middleware/auth.middleware");
const database_service_1 = require("./services/database.service");
const profile_routes_1 = __importDefault(require("./routes/profile.routes"));
const auth0_routes_1 = __importDefault(require("./routes/auth0.routes"));
const files_routes_1 = __importDefault(require("./routes/files.routes"));
// Load environment variables (for local development)
// In Lambda, environment variables are provided by AWS
if (process.env.NODE_ENV !== 'production') {
    dotenv_1.default.config();
}
const app = (0, express_1.default)();
const PORT = process.env.PORT || 3001;
// Determine CORS origins based on environment
const getAllowedOrigins = () => {
    const origins = ['http://localhost:3000']; // Always allow localhost for development
    if (process.env.NODE_ENV === 'production') {
        origins.push('https://akhilsailatchireddi.github.io');
    }
    else {
        // For local development, also allow the frontend URL if specified
        const frontendUrl = process.env.FRONTEND_URL || `http://localhost:${process.env.FRONTEND_PORT || 3000}`;
        if (!origins.includes(frontendUrl)) {
            origins.push(frontendUrl);
        }
    }
    return origins;
};
// Security middleware
app.use((0, helmet_1.default)({
    // Configure CSP for Lambda/API Gateway
    contentSecurityPolicy: process.env.NODE_ENV === 'production' ? {
        directives: {
            defaultSrc: ["'self'"],
            styleSrc: ["'self'", "'unsafe-inline'"],
            scriptSrc: ["'self'"],
            imgSrc: ["'self'", "data:", "https:"],
            connectSrc: ["'self'", "https:"],
        },
    } : false // Disable CSP in development
}));
// Rate limiting (less aggressive for Lambda due to cold starts)
const limiter = (0, express_rate_limit_1.default)({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: process.env.NODE_ENV === 'production' ? 200 : 1000, // More lenient for Lambda
    message: 'Too many requests from this IP, please try again later.',
    standardHeaders: true,
    legacyHeaders: false,
});
app.use('/api', limiter);
// CORS configuration
const corsOptions = {
    origin: getAllowedOrigins(),
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
    exposedHeaders: ['Content-Range', 'X-Content-Range']
};
app.use((0, cors_1.default)(corsOptions));
// Body parsing middleware
app.use(express_1.default.json({ limit: '10mb' }));
app.use(express_1.default.urlencoded({ extended: true, limit: '10mb' }));
// Add request logging for Lambda
app.use((req, res, next) => {
    const start = Date.now();
    res.on('finish', () => {
        const duration = Date.now() - start;
        console.log(`${req.method} ${req.path} - ${res.statusCode} (${duration}ms)`);
    });
    next();
});
// Health check endpoint
app.get('/health', (req, res) => {
    res.status(200).json({
        status: 'OK',
        message: 'PhotoVault API is running',
        timestamp: new Date().toISOString(),
        version: '1.0.0',
        environment: process.env.NODE_ENV || 'development',
        region: process.env.AWS_REGION || 'us-east-1'
    });
});
// Public API endpoint for testing (similar to Auth0 sample)
app.get("/api/external", auth_middleware_1.checkJwt, (req, res) => {
    res.send({
        msg: "Your access token was successfully validated!",
        user: req.auth
    });
});
// Routes
app.use('/api/profile', profile_routes_1.default);
app.use('/api/auth0', auth0_routes_1.default);
app.use('/api/files', files_routes_1.default);
// 404 handler
app.use('*', (req, res) => {
    res.status(404).json({
        error: 'Not Found',
        message: `Route ${req.originalUrl} not found`,
    });
});
// Error handling middleware
app.use((err, req, res, next) => {
    console.error('Error:', err);
    res.status(err.status || 500).json({
        error: process.env.NODE_ENV === 'production' ? 'Internal Server Error' : err.message,
        ...(process.env.NODE_ENV !== 'production' && { stack: err.stack }),
    });
});
// Database initialization and server startup
async function initializeApp() {
    try {
        // Initialize database connection
        console.log('🔌 Initializing database connection...');
        await database_service_1.databaseService.initialize();
        console.log('✅ Database connection established');
        // In Lambda, we don't start a server - the handler takes care of requests
        if (process.env.AWS_LAMBDA_FUNCTION_NAME) {
            console.log('🚀 PhotoVault API initialized for Lambda');
        }
        else {
            // Start server for local development
            app.listen(PORT, () => {
                console.log(`🚀 PhotoVault API server running on port ${PORT}`);
                console.log(`🌐 Environment: ${process.env.NODE_ENV || 'development'}`);
                console.log(`🔗 CORS Origins: ${getAllowedOrigins().join(', ')}`);
            });
        }
    }
    catch (error) {
        console.error('❌ Failed to initialize app:', error);
        if (!process.env.AWS_LAMBDA_FUNCTION_NAME) {
            process.exit(1);
        }
    }
}
// Initialize the app
initializeApp();
exports.default = app;
