"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.databaseService = void 0;
const mongodb_1 = require("mongodb");
class DatabaseService {
    constructor() {
        this.client = null;
        this.db = null;
        // Use MONGODB_URI environment variable for Lambda deployment
        // This will be populated from AWS SSM Parameter Store
        this.uri = process.env.MONGODB_URI || '';
        if (!this.uri) {
            console.error('⚠️  MONGODB_URI environment variable is not set');
            // Fallback to old format for local development
            const username = process.env.MONGODB_USERNAME || '<db_username>';
            const password = process.env.MONGODB_PASSWORD || '<db_password>';
            this.uri = `mongodb+srv://${username}:${password}@photovault.czk6x9q.mongodb.net/?retryWrites=true&w=majority&appName=photovault&tls=true&tlsAllowInvalidCertificates=false`;
        }
        console.log('🔗 MongoDB URI configured:', this.uri.replace(/\/\/.*@/, '//***@')); // Hide credentials in logs
    }
    async initialize() {
        if (this.db)
            return this.db;
        try {
            this.client = new mongodb_1.MongoClient(this.uri, {
                serverApi: {
                    version: mongodb_1.ServerApiVersion.v1,
                    strict: true,
                    deprecationErrors: true,
                },
                connectTimeoutMS: 30000,
                serverSelectionTimeoutMS: 30000,
                tls: true,
            });
            await this.client.connect();
            this.db = this.client.db('photovault');
            await this.createIndexes();
            return this.db;
        }
        catch (error) {
            console.error('❌ MongoDB connection failed:', error instanceof Error ? error.message : error);
            // Return a mock database object to prevent crashes
            return null;
        }
    }
    async createIndexes() {
        if (!this.db)
            throw new Error('Database not initialized');
        const usersCollection = this.db.collection('users');
        const photosCollection = this.db.collection('photos');
        // Create indexes for users collection
        await usersCollection.createIndex({ email: 1 }, { unique: true });
        await usersCollection.createIndex({ username: 1 }, { unique: true });
        await usersCollection.createIndex({ auth0Id: 1 }, { unique: true, sparse: true }); // Auth0 ID index
        // Create indexes for photos collection
        await photosCollection.createIndex({ user_id: 1 });
        await photosCollection.createIndex({ uploaded_at: -1 });
        await photosCollection.createIndex({ taken_at: -1 });
        await photosCollection.createIndex({ s3_key: 1 }, { unique: true });
    }
    async getDatabase() {
        if (!this.db) {
            await this.initialize();
        }
        return this.db;
    }
    getUsersCollection() {
        if (!this.db)
            throw new Error('Database not initialized');
        return this.db.collection('users');
    }
    getPhotosCollection() {
        if (!this.db)
            throw new Error('Database not initialized');
        return this.db.collection('photos');
    }
    // User methods
    async createUser(username, email, hashedPassword) {
        await this.getDatabase();
        const usersCollection = this.getUsersCollection();
        const now = new Date();
        const userData = {
            username,
            email,
            password: hashedPassword,
            created_at: now,
            updated_at: now
        };
        const result = await usersCollection.insertOne(userData);
        const user = await usersCollection.findOne({ _id: result.insertedId });
        if (!user)
            throw new Error('Failed to create user');
        return user;
    }
    async getUserByEmail(email) {
        await this.getDatabase();
        const usersCollection = this.getUsersCollection();
        return await usersCollection.findOne({ email });
    }
    async getUserByUsername(username) {
        await this.getDatabase();
        const usersCollection = this.getUsersCollection();
        return await usersCollection.findOne({ username });
    }
    async getUserById(id) {
        await this.getDatabase();
        const usersCollection = this.getUsersCollection();
        const objectId = typeof id === 'string' ? new mongodb_1.ObjectId(id) : id;
        return await usersCollection.findOne({ _id: objectId });
    }
    async getUserByAuth0Id(auth0Id) {
        await this.getDatabase();
        const usersCollection = this.getUsersCollection();
        return await usersCollection.findOne({ auth0Id });
    }
    async createAuth0User(userData) {
        await this.getDatabase();
        const usersCollection = this.getUsersCollection();
        // Check if username already exists and make it unique if needed
        let uniqueUsername = userData.username;
        let counter = 1;
        while (await usersCollection.findOne({ username: uniqueUsername })) {
            uniqueUsername = `${userData.username}_${counter}`;
            counter++;
        }
        const now = new Date();
        const user = {
            ...userData,
            username: uniqueUsername,
            created_at: now,
            updated_at: now
        };
        try {
            const result = await usersCollection.insertOne(user);
            const createdUser = await usersCollection.findOne({ _id: result.insertedId });
            if (!createdUser)
                throw new Error('Failed to create Auth0 user');
            return createdUser;
        }
        catch (error) {
            // Handle duplicate auth0Id error specifically
            if (error.code === 11000 && error.keyPattern?.auth0Id) {
                // User already exists, try to find and return them
                const existingUser = await usersCollection.findOne({ auth0Id: userData.auth0Id });
                if (existingUser) {
                    return existingUser;
                }
            }
            throw error;
        }
    }
    async updateAuth0User(userId, updateData) {
        await this.getDatabase();
        const usersCollection = this.getUsersCollection();
        const objectId = new mongodb_1.ObjectId(userId);
        const result = await usersCollection.findOneAndUpdate({ _id: objectId }, {
            $set: {
                ...updateData,
                updated_at: new Date()
            }
        }, { returnDocument: 'after' });
        if (!result)
            throw new Error('Failed to update Auth0 user');
        return result;
    }
    async updateUserProfile(userId, profileData) {
        await this.getDatabase();
        const usersCollection = this.getUsersCollection();
        const objectId = new mongodb_1.ObjectId(userId);
        const result = await usersCollection.findOneAndUpdate({ _id: objectId }, {
            $set: {
                profile: profileData,
                updated_at: new Date()
            }
        }, { returnDocument: 'after' });
        if (!result)
            throw new Error('Failed to update user profile');
        return result;
    }
    async updateUserProfileField(userId, fieldPath, value) {
        await this.getDatabase();
        const usersCollection = this.getUsersCollection();
        const objectId = new mongodb_1.ObjectId(userId);
        const updateQuery = {
            updated_at: new Date()
        };
        updateQuery[`profile.${fieldPath}`] = value;
        const result = await usersCollection.findOneAndUpdate({ _id: objectId }, { $set: updateQuery }, { returnDocument: 'after' });
        if (!result)
            throw new Error('Failed to update user profile field');
        return result;
    }
    async getUserProfile(userId) {
        await this.getDatabase();
        const usersCollection = this.getUsersCollection();
        const objectId = new mongodb_1.ObjectId(userId);
        return await usersCollection.findOne({ _id: objectId }, { projection: { password: 0 } } // Exclude password from response
        );
    }
    // Photo methods
    async createPhoto(photoData) {
        await this.getDatabase();
        const photosCollection = this.getPhotosCollection();
        const photoDocument = {
            ...photoData,
            uploaded_at: new Date()
        };
        const result = await photosCollection.insertOne(photoDocument);
        const photo = await photosCollection.findOne({ _id: result.insertedId });
        if (!photo)
            throw new Error('Failed to create photo');
        return photo;
    }
    async getUserPhotos(userId, limit = 50, offset = 0) {
        await this.getDatabase();
        const photosCollection = this.getPhotosCollection();
        const objectId = typeof userId === 'string' ? new mongodb_1.ObjectId(userId) : userId;
        return await photosCollection
            .find({ user_id: objectId })
            .sort({ uploaded_at: -1 })
            .skip(offset)
            .limit(limit)
            .toArray();
    }
    async getPhotosByDateRange(userId, startDate, endDate) {
        await this.getDatabase();
        const photosCollection = this.getPhotosCollection();
        const objectId = typeof userId === 'string' ? new mongodb_1.ObjectId(userId) : userId;
        return await photosCollection
            .find({
            user_id: objectId,
            uploaded_at: {
                $gte: startDate,
                $lte: endDate
            }
        })
            .sort({ uploaded_at: -1 })
            .toArray();
    }
    async getPhotosByYearMonth(userId, year, month) {
        await this.getDatabase();
        const photosCollection = this.getPhotosCollection();
        const objectId = typeof userId === 'string' ? new mongodb_1.ObjectId(userId) : userId;
        let startDate;
        let endDate;
        if (month !== undefined) {
            startDate = new Date(year, month - 1, 1);
            endDate = new Date(year, month, 0, 23, 59, 59, 999);
        }
        else {
            startDate = new Date(year, 0, 1);
            endDate = new Date(year, 11, 31, 23, 59, 59, 999);
        }
        return await photosCollection
            .find({
            user_id: objectId,
            uploaded_at: {
                $gte: startDate,
                $lte: endDate
            }
        })
            .sort({ uploaded_at: -1 })
            .toArray();
    }
    async getPhotoById(id, userId) {
        await this.getDatabase();
        const photosCollection = this.getPhotosCollection();
        const photoObjectId = typeof id === 'string' ? new mongodb_1.ObjectId(id) : id;
        const userObjectId = typeof userId === 'string' ? new mongodb_1.ObjectId(userId) : userId;
        return await photosCollection.findOne({
            _id: photoObjectId,
            user_id: userObjectId
        });
    }
    async deletePhoto(id, userId) {
        await this.getDatabase();
        const photosCollection = this.getPhotosCollection();
        const photoObjectId = typeof id === 'string' ? new mongodb_1.ObjectId(id) : id;
        const userObjectId = typeof userId === 'string' ? new mongodb_1.ObjectId(userId) : userId;
        const result = await photosCollection.deleteOne({
            _id: photoObjectId,
            user_id: userObjectId
        });
        return result.deletedCount > 0;
    }
    async getPhotoStats(userId) {
        await this.getDatabase();
        const photosCollection = this.getPhotosCollection();
        const objectId = typeof userId === 'string' ? new mongodb_1.ObjectId(userId) : userId;
        const stats = await photosCollection.aggregate([
            { $match: { user_id: objectId } },
            {
                $group: {
                    _id: null,
                    total_photos: { $sum: 1 },
                    total_size: { $sum: '$file_size' },
                    first_upload: { $min: '$uploaded_at' },
                    last_upload: { $max: '$uploaded_at' }
                }
            }
        ]).toArray();
        return stats.length > 0 ? stats[0] : {
            total_photos: 0,
            total_size: 0,
            first_upload: null,
            last_upload: null
        };
    }
    async close() {
        if (this.client) {
            await this.client.close();
            this.client = null;
            this.db = null;
        }
    }
}
exports.databaseService = new DatabaseService();
