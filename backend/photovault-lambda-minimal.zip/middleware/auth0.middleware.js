"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.optionalAuth0Middleware = exports.auth0Middleware = void 0;
const auth0_service_1 = require("../services/auth0.service");
/**
 * Auth0 authentication middleware
 * Verifies Auth0 JWT token and syncs user with MongoDB
 */
const auth0Middleware = async (req, res, next) => {
    try {
        const authHeader = req.headers.authorization;
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return res.status(401).json({
                success: false,
                message: 'Access token is required',
            });
        }
        const token = authHeader.substring(7); // Remove 'Bearer ' prefix
        const user = await auth0_service_1.auth0Service.processAuth0Token(token);
        if (!user) {
            return res.status(401).json({
                success: false,
                message: 'Invalid or expired token',
            });
        }
        req.user = user;
        next();
    }
    catch (error) {
        console.error('Auth0 middleware error:', error);
        return res.status(401).json({
            success: false,
            message: 'Authentication failed',
        });
    }
};
exports.auth0Middleware = auth0Middleware;
/**
 * Optional Auth0 authentication middleware
 * Adds user to request if token is provided, but doesn't fail if not
 */
const optionalAuth0Middleware = async (req, res, next) => {
    try {
        const authHeader = req.headers.authorization;
        if (authHeader && authHeader.startsWith('Bearer ')) {
            const token = authHeader.substring(7);
            const user = await auth0_service_1.auth0Service.processAuth0Token(token);
            if (user) {
                req.user = user;
            }
        }
        next();
    }
    catch (error) {
        // Don't fail on optional auth errors
        console.warn('Optional Auth0 middleware warning:', error);
        next();
    }
};
exports.optionalAuth0Middleware = optionalAuth0Middleware;
